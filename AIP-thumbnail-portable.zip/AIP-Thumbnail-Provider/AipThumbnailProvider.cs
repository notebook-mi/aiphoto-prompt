// AIP Thumbnail Provider —— 让 Windows 资源管理器直接显示 .aip 容器里最新代图像的缩略图。
//
// 原理：给 .aip 扩展名注册一个 Shell 缩略图处理器（IThumbnailProvider）。
// 资源管理器请求缩略图时把文件交给本组件；本组件按 AIP v1 的 FOOTER 段表
// 直接定位图像段字节，解码后等比缩放到请求尺寸，返回 HBITMAP。
//
// 容器里的图像段永远是「最新代」的图像（派生 / 删除回退 / 编辑都原地重写同一个文件），
// 所以这里读到的自然就是最新代次图片，不需要额外逻辑。
//
// 字节布局（小端，见 aipstudio/container.py）：
//   HEADER  '<4sHHII'  = 'AIP1' + u16 版本 + u16 标志 + u32 manifestLen + u32 footerOffset
//   FOOTER  '<4sHHIIIIII32s4s48s' = 'AIPF' + ver + flags
//                                 + u32 manifestOff + u32 manifestLen
//                                 + u32 promptOff   + u32 promptLen
//                                 + u32 imageOff    + u32 imageLen   ← 图像段就在这儿
//                                 + 32B sha256 + 'END!' + 48B 保留    （共 116 B，位于文件末尾）
// 所以整个解析 = 读 16 B 头 + 读末尾 116 B 段表 + 按偏移切图像字节，不碰 JSON，没有额外依赖。
//
// 编译：build.bat   自检：verify.bat   注册：register.bat   卸载：unregister.bat
//
// 健壮性：所有解析 / 解码路径都兜底 —— 损坏文件、异常容器一律返回空缩略图
// （资源管理器回退到默认图标），绝不让组件崩掉拖垮 explorer。

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

// WPF 的 WIC 解码器用来兜 GDI+ 不认识的格式（WebP 最常见）。
// 它依赖 WindowsBase / PresentationCore —— 这两个不在编译器默认搜索路径里，
// 所以 build.bat 会先把它们在 GAC 里找出来，用完整路径传给 csc，并打开 WITH_WIC。
// 万一这台机器上找不到（组件照样要能编过），下面用 #if 整段屏蔽，只是少掉 WebP 支持。
#if WITH_WIC
using WicImaging = System.Windows.Media.Imaging;
using WicMedia = System.Windows.Media;
#endif

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyTitle("AIP Thumbnail Provider")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]

namespace AipThumb
{
    // ── Windows Shell 缩略图 COM 接口（系统定义的 GUID 与签名，逐字不可改） ──

    // 资源管理器用来问「给我一张 cx×cx 以内的缩略图」的接口。
    // GUID 固定为 e357fccd-a995-4576-b01f-234630154e96，注册表里也用同一个。
    [ComImport]
    [Guid("e357fccd-a995-4576-b01f-234630154e96")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IThumbnailProvider
    {
        void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha);
    }

    // 优先方式：shell 用流把文件内容递过来（网络位置、压缩包内的文件也能取）。
    [ComImport]
    [Guid("b824b49d-22ac-4161-ac8a-9916e8fa3f7f")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IInitializeWithStream
    {
        void Initialize([MarshalAs(UnmanagedType.Interface)] IStream pstream, uint grfMode);
    }

    // 备选方式：有些 shell 路径只给文件路径。
    [ComImport]
    [Guid("b7d14566-0509-4cce-a71f-0a554233bd9b")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IInitializeWithFile
    {
        void Initialize([MarshalAs(UnmanagedType.LPWStr)] string pszFilePath, uint grfMode);
    }

    [ComVisible(true)]
    [Guid("8C7E9F3D-2B5A-4E6D-9A1C-4F7B2D8E5C60")]
    [ClassInterface(ClassInterfaceType.None)]
    public sealed class AipThumbnailProvider : IThumbnailProvider, IInitializeWithStream, IInitializeWithFile
    {
        private const uint WTSAT_RGB = 1;
        private const uint WTSAT_ARGB = 2;

        private const int HEADER_SIZE = 16;
        private const int FOOTER_SIZE = 116;
        private const int FOOTER_IMAGE_OFF = 24;   // footer 内 image_offset 的偏移
        private const int FOOTER_IMAGE_LEN = 28;   // footer 内 image_length 的偏移
        private const int FOOTER_END_MARK = 64;    // footer 内 'END!' 的偏移

        private IStream _stream;
        private string _path;

        public AipThumbnailProvider() { }

        // ── 初始化 ──

        public void Initialize(IStream pstream, uint grfMode)
        {
            // 不在这里读文件：资源管理器可能一口气问几十个文件的缩略图，
            // 真正要出图时再按偏移读，省内存也省时间。
            _stream = pstream;
            _path = null;
        }

        public void Initialize(string pszFilePath, uint grfMode)
        {
            _path = pszFilePath;
            _stream = null;
        }

        // ── 出图 ──

        public void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha)
        {
            phbmp = IntPtr.Zero;
            pdwAlpha = WTSAT_RGB;
            try
            {
                if (cx == 0 || cx > 4096) cx = 256;
                byte[] image = ExtractImage();
                if (image == null) return;

                Bitmap bmp = DecodeImage(image);
                if (bmp == null) return;

                using (bmp)
                {
                    using (Bitmap small = Scale(bmp, (int)cx))
                    {
                        if (small == null) return;
                        bool alpha = HasTransparency(small);
                        pdwAlpha = alpha ? WTSAT_ARGB : WTSAT_RGB;
                        phbmp = ToHBitmap(small, alpha);
                    }
                }
            }
            catch
            {
                phbmp = IntPtr.Zero;   // 任何异常都不允许冒出 COM 边界
            }
        }

        // ── AIP 容器解析：读头 + 读尾巴段表 + 按偏移切图像 ──

        private byte[] ExtractImage()
        {
            if (_path != null)
            {
                using (FileStream fs = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    return ExtractVia(delegate (long off, int len) { return ReadFile(fs, off, len); }, fs.Length);
            }
            if (_stream != null)
            {
                long size = StreamLength(_stream);
                if (size <= 0) return null;
                IStream s = _stream;
                return ExtractVia(delegate (long off, int len) { return ReadStream(s, off, len); }, size);
            }
            return null;
        }

        private static byte[] ExtractVia(Func<long, int, byte[]> reader, long totalSize)
        {
            if (totalSize < HEADER_SIZE + FOOTER_SIZE) return null;

            byte[] head = reader(0, HEADER_SIZE);
            if (head == null || head.Length < HEADER_SIZE) return null;
            if (!(head[0] == (byte)'A' && head[1] == (byte)'I' && head[2] == (byte)'P' && head[3] == (byte)'1'))
                return null;

            int footerOffset = BitConverter.ToInt32(head, 12);
            if (footerOffset < HEADER_SIZE || (long)footerOffset + FOOTER_SIZE > totalSize) return null;

            byte[] footer = reader(footerOffset, FOOTER_SIZE);
            if (footer == null || footer.Length < FOOTER_SIZE) return null;
            if (!(footer[0] == (byte)'A' && footer[1] == (byte)'I' && footer[2] == (byte)'P' && footer[3] == (byte)'F'))
                return null;
            if (!(footer[FOOTER_END_MARK] == (byte)'E' && footer[FOOTER_END_MARK + 1] == (byte)'N'
                  && footer[FOOTER_END_MARK + 2] == (byte)'D' && footer[FOOTER_END_MARK + 3] == (byte)'!'))
                return null;

            int imageOffset = BitConverter.ToInt32(footer, FOOTER_IMAGE_OFF);
            int imageLength = BitConverter.ToInt32(footer, FOOTER_IMAGE_LEN);
            if (imageOffset < HEADER_SIZE || imageLength <= 0) return null;
            if ((long)imageOffset + imageLength > totalSize) return null;

            return reader(imageOffset, imageLength);
        }

        private static byte[] ReadFile(FileStream fs, long offset, int count)
        {
            if (offset < 0 || count <= 0 || offset + count > fs.Length) return null;
            byte[] buf = new byte[count];
            fs.Seek(offset, SeekOrigin.Begin);
            int total = 0;
            while (total < count)
            {
                int n = fs.Read(buf, total, count - total);
                if (n <= 0) break;
                total += n;
            }
            return total < count ? null : buf;
        }

        // 托管签名里 IStream.Read 的第三参是 IntPtr（写回实际读到的字节数）
        private static byte[] ReadStream(IStream s, long offset, int count)
        {
            if (offset < 0 || count <= 0) return null;
            IntPtr pos = Marshal.AllocCoTaskMem(8);
            IntPtr readPtr = Marshal.AllocCoTaskMem(4);
            try
            {
                s.Seek(offset, 0 /* STREAM_SEEK_SET */, pos);
                byte[] buf = new byte[count];
                int total = 0;
                while (total < count)
                {
                    byte[] chunk = new byte[count - total];
                    s.Read(chunk, chunk.Length, readPtr);
                    int n = Marshal.ReadInt32(readPtr);
                    if (n <= 0) break;
                    if (n > chunk.Length) n = chunk.Length;
                    Array.Copy(chunk, 0, buf, total, n);
                    total += n;
                }
                return total < count ? null : buf;
            }
            finally
            {
                Marshal.FreeCoTaskMem(pos);
                Marshal.FreeCoTaskMem(readPtr);
            }
        }

        private static long StreamLength(IStream s)
        {
            IntPtr pos = Marshal.AllocCoTaskMem(8);
            try
            {
                s.Seek(0, 2 /* STREAM_SEEK_END */, pos);
                return Marshal.ReadInt64(pos);
            }
            catch { return -1; }
            finally { Marshal.FreeCoTaskMem(pos); }
        }

        // ── 解码与缩放 ──

        // 主路径 GDI+（PNG / JPEG / GIF / BMP / TIFF），失败回退 WIC
        // （覆盖 WebP 等 WIC 认识的格式：Win11 自带，Win10 需装「Webp 图像扩展」）。
        private static Bitmap DecodeImage(byte[] image)
        {
            try
            {
                using (MemoryStream ms = new MemoryStream(image, false))
                using (Image src = Image.FromStream(ms, false, true))
                {
                    // 复制一份，脱离流（Image.FromStream 要求流在图像生命周期内保持打开）
                    Bitmap copy = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);
                    using (Graphics g = Graphics.FromImage(copy))
                    {
                        g.Clear(Color.Transparent);
                        g.CompositingMode = CompositingMode.SourceCopy;
                        g.DrawImage(src, new Rectangle(0, 0, src.Width, src.Height));
                    }
                    return copy;
                }
            }
            catch { }

#if WITH_WIC
            try { return DecodeViaWic(image); }
            catch { return null; }
#else
            return null;   // 这次编译没带 WIC，只认 GDI+ 能解的格式
#endif
        }

#if WITH_WIC
        private static Bitmap DecodeViaWic(byte[] image)
        {
            using (MemoryStream ms = new MemoryStream(image, false))
            {
                WicImaging.BitmapDecoder decoder = WicImaging.BitmapDecoder.Create(
                    ms, WicImaging.BitmapCreateOptions.PreservePixelFormat, WicImaging.BitmapCacheOption.OnLoad);
                WicImaging.FormatConvertedBitmap src = new WicImaging.FormatConvertedBitmap(
                    decoder.Frames[0], WicMedia.PixelFormats.Bgra32, null, 0);
                int w = src.PixelWidth, h = src.PixelHeight;
                if (w <= 0 || h <= 0) return null;

                Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
                BitmapData data = bmp.LockBits(new Rectangle(0, 0, w, h),
                                               ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
                try
                {
                    src.CopyPixels(new System.Windows.Int32Rect(0, 0, w, h), data.Scan0,
                                   data.Stride * h, data.Stride);
                }
                finally { bmp.UnlockBits(data); }
                return bmp;
            }
        }
#endif

        /// <summary>本次编译是否带上了 WIC 兜底（决定能不能解 WebP）。verify.bat 会打印它。</summary>
        public static bool HasWicFallback
        {
#if WITH_WIC
            get { return true; }
#else
            get { return false; }
#endif
        }

        private static Bitmap Scale(Bitmap src, int cx)
        {
            int w = src.Width, h = src.Height;
            if (w <= 0 || h <= 0) return null;
            double scale = Math.Min((double)cx / w, (double)cx / h);
            if (scale > 1.0) scale = 1.0;              // 缩略图不放大
            int tw = Math.Max(1, (int)Math.Round(w * scale));
            int th = Math.Max(1, (int)Math.Round(h * scale));

            Bitmap outBmp = new Bitmap(tw, th, PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(outBmp))
            {
                g.Clear(Color.Transparent);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.DrawImage(src, new Rectangle(0, 0, tw, th));
            }
            return outBmp;
        }

        /// <summary>扫描是否真的存在半透明像素 —— 全不透明就按 RGB 交回去，省掉多余的 alpha 处理。</summary>
        private static bool HasTransparency(Bitmap bmp)
        {
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
                                           ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                byte[] row = new byte[bmp.Width * 4];
                for (int y = 0; y < bmp.Height; y++)
                {
                    Marshal.Copy(IntPtr.Add(data.Scan0, y * data.Stride), row, 0, row.Length);
                    for (int i = 3; i < row.Length; i += 4)
                        if (row[i] != 255) return true;
                }
                return false;
            }
            finally { bmp.UnlockBits(data); }
        }

        // ── 交给 shell 的 HBITMAP ──
        //
        // 不用 Bitmap.GetHbitmap()：它返回的 DIB 里 alpha 不可靠（常见效果是缩略图一片黑
        // 或全透明）。这里显式建一个 32bpp 顶向下的 DIB 段，并按 Windows 缩略图的约定
        // 做 alpha 预乘（premultiplied BGRA，与官方样例用的 32bppPBGRA 一致）。

        [StructLayout(LayoutKind.Sequential)]
        private struct BITMAPINFOHEADER
        {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;
        }

        [DllImport("gdi32.dll", SetLastError = true)]
        private static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFOHEADER pbmi,
                                                     uint usage, out IntPtr ppvBits,
                                                     IntPtr hSection, uint offset);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        private const uint DIB_RGB_COLORS = 0;
        private const int BI_RGB = 0;

        private static IntPtr ToHBitmap(Bitmap bmp, bool premultiply)
        {
            int w = bmp.Width, h = bmp.Height;
            BITMAPINFOHEADER bmi = new BITMAPINFOHEADER();
            bmi.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
            bmi.biWidth = w;
            bmi.biHeight = -h;                 // 负高度 = 顶向下，与 Bitmap 的行序一致
            bmi.biPlanes = 1;
            bmi.biBitCount = 32;
            bmi.biCompression = BI_RGB;

            IntPtr bits;
            IntPtr hbmp = CreateDIBSection(IntPtr.Zero, ref bmi, DIB_RGB_COLORS, out bits, IntPtr.Zero, 0);
            if (hbmp == IntPtr.Zero || bits == IntPtr.Zero) return IntPtr.Zero;

            try
            {
                BitmapData data = bmp.LockBits(new Rectangle(0, 0, w, h),
                                               ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                try
                {
                    byte[] row = new byte[w * 4];
                    for (int y = 0; y < h; y++)
                    {
                        Marshal.Copy(IntPtr.Add(data.Scan0, y * data.Stride), row, 0, row.Length);
                        if (premultiply)
                        {
                            for (int i = 0; i < row.Length; i += 4)
                            {
                                int a = row[i + 3];
                                if (a == 255) continue;
                                if (a == 0) { row[i] = 0; row[i + 1] = 0; row[i + 2] = 0; continue; }
                                row[i] = (byte)(row[i] * a / 255);          // B
                                row[i + 1] = (byte)(row[i + 1] * a / 255);  // G
                                row[i + 2] = (byte)(row[i + 2] * a / 255);  // R
                            }
                        }
                        Marshal.Copy(row, 0, IntPtr.Add(bits, y * w * 4), row.Length);
                    }
                }
                finally { bmp.UnlockBits(data); }
                return hbmp;
            }
            catch
            {
                DeleteObject(hbmp);
                return IntPtr.Zero;
            }
        }

        // ── 自检入口（verify.bat 调用；不参与 COM，可直接调） ──

        /// <summary>
        /// 走完整链路验证一个 .aip：读段表 → 定位图像段 → 解码 → 缩放到 256 → 建 HBITMAP。
        /// 返回人类可读的结果串，任何一步失败都说明原因。
        /// </summary>
        public static string ProbeFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return "FAIL 文件不存在: " + path;
                byte[] image;
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    image = ExtractVia(delegate (long off, int len) { return ReadFile(fs, off, len); }, fs.Length);
                if (image == null)
                    return "FAIL 不是有效的 AIP v1 容器（魔数 / FOOTER 段表 / 图像段读不出来）";

                Bitmap bmp = DecodeImage(image);
                if (bmp == null)
                    return string.Format(
                        "FAIL 图像段取到了（{0} 字节）但解码失败 —— 该格式 GDI+ 解不了{1}",
                        image.Length,
                        HasWicFallback
                            ? "，WIC 兜底也没成（系统可能缺该格式的编解码器，WebP 常见）"
                            : "，且本次编译没带 WIC 兜底（重新跑 build.bat 让它把 WPF 引用加上）");
                try
                {
                    using (Bitmap small = Scale(bmp, 256))
                    {
                        bool alpha = HasTransparency(small);
                        IntPtr hb = ToHBitmap(small, alpha);
                        if (hb == IntPtr.Zero) return "FAIL 生成 HBITMAP 失败";
                        DeleteObject(hb);
                        return string.Format("OK 图像段 {0} 字节 · 原图 {1}×{2} · 缩略图 {3}×{4} · {5}",
                            image.Length, bmp.Width, bmp.Height, small.Width, small.Height,
                            alpha ? "带透明" : "不透明");
                    }
                }
                finally { bmp.Dispose(); }
            }
            catch (Exception ex)
            {
                return "FAIL " + ex.GetType().Name + ": " + ex.Message;
            }
        }
    }
}
