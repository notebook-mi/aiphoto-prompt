﻿# AIP 缩略图处理器 · 自检
# 逐项检查：组件文件 / 能否加载 / 真实容器解析 / 注册表 / 系统开关
param([string]$Sample = "")

$ErrorActionPreference = "Continue"
$here  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$CLSID = "{8C7E9F3D-2B5A-4E6D-9A1C-4F7B2D8E5C60}"
$THUMB = "{e357fccd-a995-4576-b01f-234630154e96}"
$OLD   = "{e357fccd-a995-4576-bd01-234f3c5c74c0}"

$script:pass = 0
$script:fail = 0

function Ok($m)   { $script:pass++; Write-Host ("  [OK]  " + $m) -ForegroundColor Green }
function Bad($m)  { $script:fail++; Write-Host ("  [XX]  " + $m) -ForegroundColor Red }
function Info($m) { Write-Host ("  [--]  " + $m) -ForegroundColor Gray }

Write-Host ""
Write-Host "============= AIP 缩略图处理器 · 自检 ============="
Write-Host ""

# ---------------------------------------------------------------- 1 组件文件
Write-Host "[1] 组件文件"
$dll = Join-Path $here "AipThumb.dll"
if (Test-Path $dll) {
  $fi = Get-Item $dll
  Ok ("AipThumb.dll 存在 · " + $fi.Length + " 字节 · " + $fi.LastWriteTime.ToString("yyyy-MM-dd HH:mm"))
} else {
  Bad "AipThumb.dll 不存在 —— 先双击 build.bat 编译"
}

# ---------------------------------------------------------------- 2 能否加载
Write-Host ""
Write-Host "[2] 组件能否被 CLR 加载"
$type = $null
if (Test-Path $dll) {
  try {
    $asm  = [Reflection.Assembly]::LoadFrom($dll)
    $name = $asm.GetName()
    Info ("程序集 " + $name.Name + " · 版本 " + $name.Version)
    if ($name.Version.ToString() -ne "1.0.0.0") {
      Bad ("程序集版本是 " + $name.Version + "，但注册表里写的是 1.0.0.0 —— 两边必须一致，重新用 build.bat 编一次")
    } else {
      Ok "程序集版本 1.0.0.0，与注册表一致"
    }
    $type = $asm.GetType("AipThumb.AipThumbnailProvider")
    if ($type -ne $null) { Ok "找到类型 AipThumb.AipThumbnailProvider" }
    else { Bad "程序集里没有类型 AipThumb.AipThumbnailProvider" }
    if ($type -ne $null) {
      $wic = $type.GetProperty("HasWicFallback").GetValue($null)
      if ($wic) { Info "带 WIC 兜底：GDI+ 解不了的格式（含 WebP）也能出缩略图" }
      else { Info "未带 WIC 兜底：只认 PNG/JPEG 等 GDI+ 格式，WebP 会没缩略图" }
    }
  } catch {
    Bad ("加载失败：" + $_.Exception.Message)
  }
} else {
  Info "跳过（没有 dll）"
}

# ---------------------------------------------------------------- 3 真实解析
Write-Host ""
Write-Host "[3] 拿一个真实 .aip 走完整链路"
$sample = ""
if ($Sample -ne "" -and (Test-Path $Sample)) { $sample = (Resolve-Path $Sample).Path }
if ($sample -eq "") {
  $roots = @("$here\..\build", "$here\..\dist", "$here\..")
  foreach ($r in $roots) {
    if (Test-Path $r) {
      $f = Get-ChildItem -Path $r -Filter *.aip -Recurse -ErrorAction SilentlyContinue |
           Where-Object { $_.Length -gt 1000 } | Select-Object -First 1
      if ($f -ne $null) { $sample = $f.FullName; break }
    }
  }
}
if ($sample -eq "") {
  Info "没找到可测的 .aip；也可以把某个 .aip 直接拖到 verify.bat 上再跑"
} else {
  Info ("样本 " + $sample)
  if ($type -ne $null) {
    try {
      $r = $type.GetMethod("ProbeFile").Invoke($null, @($sample))
      if ($r -like "OK*") { Ok ("解析链路正常：" + $r) }
      else { Bad ("解析链路异常：" + $r) }
    } catch {
      Bad ("调用 ProbeFile 出错：" + $_.Exception.Message)
    }
  }
}

# ---------------------------------------------------------------- 4 注册表
Write-Host ""
Write-Host "[4] 注册表"
$k1 = "HKCU:\Software\Classes\.aip\ShellEx\$THUMB"
if (Test-Path $k1) {
  $v = (Get-ItemProperty -Path $k1)."(default)"
  if ($v -eq $CLSID) { Ok ("缩略图处理器已挂到 .aip → " + $v) }
  else { Bad ("处理器指向 " + $v + "，应该是 " + $CLSID + " —— 重跑 register.bat") }
} else {
  Bad ("缺少 " + $k1 + " —— 运行 register.bat")
}

$k2 = "HKCU:\Software\Classes\CLSID\$CLSID\InprocServer32"
if (Test-Path $k2) {
  $p = Get-ItemProperty -Path $k2
  if ($p."(default)" -eq "mscoree.dll") { Ok "COM 服务器指向 mscoree.dll（托管组件必需）" }
  else { Bad ("InprocServer32 = " + $p."(default) + "，应为 mscoree.dll") }
  foreach ($need in @("Class","Assembly","RuntimeVersion","CodeBase","ThreadingModel")) {
    if ($p.$need) { Info ($need + " = " + $p.$need) } else { Bad ("缺少注册表值 " + $need) }
  }
  if ($p.CodeBase) {
    $f = $p.CodeBase -replace "^file:///", "" -replace "%20", " "
    if (Test-Path $f) { Ok "CodeBase 指向的 DLL 确实存在" }
    else { Bad ("CodeBase 指向的文件不存在：" + $f) }
  }
} else {
  Bad ("缺少 " + $k2 + " —— 运行 register.bat")
}

if (Test-Path "HKCU:\Software\Classes\.aip\ShellEx\$OLD") {
  Bad "还有上一版写错 GUID 的处理器键残留 —— 重跑 register.bat 会清掉"
} else {
  Ok "没有旧版错误按键残留"
}

# ---------------------------------------------------------------- 5 系统开关
Write-Host ""
Write-Host "[5] 系统相关开关"
$adv = Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -ErrorAction SilentlyContinue
if ($adv -ne $null -and $adv.IconsOnly -eq 1) {
  Bad "系统勾选了「始终显示图标，从不显示缩略图」—— 文件夹选项 → 查看 里取消它"
} else {
  Ok "缩略图显示开关正常（未勾选「始终显示图标」）"
}
$acp = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Nls\CodePage").ACP
Info ("系统 ANSI 代码页 " + $acp)

# ---------------------------------------------------------------- 小结
Write-Host ""
Write-Host "=================== 小结 ==================="
Write-Host ("  通过 " + $script:pass + " 项 · 失败 " + $script:fail + " 项")
if ($script:fail -eq 0) {
  Write-Host "  组件与注册都没问题。若资源管理器仍显示图标，请确认：" -ForegroundColor Yellow
  Write-Host "    - 视图已切到「大图标 / 超大图标」（列表/详细信息视图本来就不出缩略图）" -ForegroundColor Yellow
  Write-Host "    - 重启一次资源管理器，让新的处理器被加载" -ForegroundColor Yellow
} else {
  Write-Host "  按上面标 [XX] 的项修：多数情况是「没编译」或「没注册」。" -ForegroundColor Yellow
}
Write-Host ""
